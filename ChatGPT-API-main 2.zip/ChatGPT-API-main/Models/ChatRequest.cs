﻿using System.ComponentModel;

namespace OpenAIApi.Models
{
    public enum ChatRole
    {
        system = 0,
        user = 1,
        assistant = 2
    }

    public class ChatRequest
    {
        [DefaultValue("gpt-3.5-turbo")]
        public string model { get; set; }
        public List<ChatMessage> messages { get; set; }

        public ChatRequest()
        {
            model = "gpt-3.5-turbo";
        }

    }

    public class Request
    {
        public BotSettings botSettings{ get; set; }
        public List<ChatMessage> messages { get; set; }

        //public ChatRequest generaterequest() {
        //    ChatMessage systemMessage = new ChatMessage()
        //    {
        //        role = "system",
        //        content = botSettings.generatPrompt()
        //    };

        //    List<ChatMessage> chatMessages= new List<ChatMessage>();

        //    chatMessages.Add(systemMessage);

        //    return new ChatRequest()
        //    {
        //        messages = chatMessages
        //    };
        //}
    }


    public class ChatMessage
    {
        [DefaultValue("user")]
        public string role { get; set; }
        [DefaultValue("where is my shipment")]
        public string content { get; set; }
    }

    public class BotSettings
    {
        [DefaultValue("GLTExpress")]
        public String name { get; set; }

        [DefaultValue("random arabic name")]
        public string botName { get; set; }
        [DefaultValue("Call center representative")]
        public String position { get; set; }
        [DefaultValue("gltmena.com")]
        public String  url { get; set; }
        [DefaultValue("arabic")]
        public String language { get; set; }
        [DefaultValue("logistics")]
        public String feild { get; set; }
        [DefaultValue(1)]
        public int options { get; set; }

        [DefaultValue("")]
        public String moreInfo { get; set; }


        public string generatPrompt()
        {
            String _urlPhrase;

            if (url != null)
            {
                _urlPhrase = "\n the company website is " + url;
            }

            else
            {
                _urlPhrase = "";
            }

            Dictionary<string, string> p = new Dictionary<string, string>()
            {
                
                //{ "nameString", "\n your name is a" + "Ali"},
                { "botRole", " You are an assistant for a "  + position },
                { "rolePhrase",  "\n all user messages are a messages that the "  + position +  " receives,give a replay to the message" },
                { "feildPhrase" , "\n The "  + position +  " works for a "+ feild + " company called " + name},
                { "urlPhrase", _urlPhrase},
                //{ "moreInfo", moreinfo }
                //{ "languagePhrase" , "\n Always reply using the Najdi arabic language"}, 
                //{ "dialectPhrase", "\n use the " + dialect + " dialect when the user message is in the" + language + "language" }
            };

            string prompt = "";
            p.Values.ToList().ForEach(b => prompt += b);

            System.Diagnostics.Debug.WriteLine(prompt
              );
            return prompt;
        }
    }
}
