﻿//using System;
//namespace OpenAIApi.Models
//{
//	public class BotSettings
//	{

//		String name;
//		string botName;
//		String url;
//		String language;
//		String feild;
//		int options;
		
//		public BotSettings()
//		{

//		}

//		string generatPrompt()
//		{
//			return "you are a bot named mohamed"; 
//		}
//	}
//}

