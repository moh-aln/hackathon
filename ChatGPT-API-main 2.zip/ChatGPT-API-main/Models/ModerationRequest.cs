﻿namespace OpenAIApi.Models
{
    public class ModerationRequest
    {
        public string input { get; set; }
    }
}
