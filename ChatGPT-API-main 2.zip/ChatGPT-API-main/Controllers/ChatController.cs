using Microsoft.AspNetCore.Mvc;
using OpenAIApi.Models;
using OpenAIApi.Services;
using Swashbuckle.AspNetCore.Annotations;

namespace OpenAIApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [SwaggerTag("Endpoints for the ChatGPT chat model")]
    public class ChatController : ControllerBase
    {
        private readonly ILogger<ChatController> _logger;
        private readonly IAIService _openAIService;
        private readonly IhandleRequest ihandleRequest;


        public ChatController(ILogger<ChatController> logger, IAIService completionService, IhandleRequest handleR)
        {
            _logger = logger;
            _openAIService = completionService;
            ihandleRequest = handleR;

        }

        //[HttpGet()]
        //public async Task<IActionResult> GetCompletionFromPrompt(string prompt)
        //{
        //    try
        //    {
        //        var response = await _openAIService.GetChatResponseAsync(prompt);
        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        [HttpPost("FromRequest")]
        public async Task<IActionResult> GetCompletionFromRequest([FromBody]Request request)
        {
            try
            {
                var response = await ihandleRequest.RrAsync(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
    
}

