﻿using System;
using OpenAIApi.Models;

namespace OpenAIApi.Services
{
	public class handleRequest : IhandleRequest
    {

        private readonly IAIService _openAIService;

        public handleRequest(IAIService iis)
        {
            _openAIService = iis;
        }
        public async Task<CompletionResponse> RrAsync(Request r)
        {
            ChatMessage systemMessage = new ChatMessage()
            {
                role = "system",
                content = r.botSettings.generatPrompt()
            };

            List<ChatMessage> chatMessages = new List<ChatMessage>();

            chatMessages.Add(systemMessage);
            r.messages.ForEach(a => chatMessages.Add(a));
            

            var result =  new ChatRequest()
            {
                model = "gpt-3.5-turbo",
                messages = chatMessages
            };



            var finalRes = await _openAIService.GetChatResponseAsync(result);
            return finalRes;
           
        }
    }
    public interface IhandleRequest
    {
         Task<CompletionResponse> RrAsync(Request r);
    }
}

