﻿using System.ComponentModel;

namespace CoreProject.Models
{
    public class ChatResponse
    {
        public string Text { get; set; }
        public double Score { get; set; }
    }
    public class ChatMessage
    {
        [DefaultValue("user")]
        public string role { get; set; }
        [DefaultValue("where is my shipment")]
        public string content { get; set; }
    }
}
