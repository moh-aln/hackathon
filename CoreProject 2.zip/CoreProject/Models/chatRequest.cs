﻿using System;
namespace CoreProject.Models
{


    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class BotSettings
    {
        public string name { get; set; }
        public string botName { get; set; }
        public string position { get; set; }
        public string url { get; set; }
        public string language { get; set; }
        public string feild { get; set; }
        public int options { get; set; }
        public string moreInfo { get; set; }
    }



    public class chatRequest
    {
        public BotSettings botSettings { get; set; }
        public List<Message> messages { get; set; }
    }


}



