﻿//using CoreProject.Models;
//using Microsoft.AspNetCore.Mvc;
//using System.Diagnostics;
//using Newtonsoft.Json;
//using RestSharp;



//namespace CoreProject.Controllers
//{
//    public class HomeController : Controller
//    {
//        private readonly ILogger<HomeController> _logger;

//        public HomeController(ILogger<HomeController> logger)
//        {
//            _logger = logger;
//        }


//        public IActionResult Index()
//        {
//            return View();
//        }


//        public class ChatController : Controller
//        {
//            public IActionResult Index()
//            {
//                return View();
//            }

//            [HttpPost]
//            public IActionResult Index(string message)
//            {
//                // Send user message to ChatGPT API
//                var client = new RestClient("https://api.openai.com/v1/engines/davinci-codex/completions");
//                var request = new RestRequest("engines/davinci-codex/completions", Method.Post);


//                request.AddHeader("content-type", "application/json");
//                request.AddHeader("Authorization", "Bearer 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");
//                request.AddParameter("application/json", JsonConvert.SerializeObject(new
//                {
//                    prompt = message,
//                    max_tokens = 50,
//                    n = 1,
//                    stop = "\n",
//                    temperature = 0.7
//                }), ParameterType.RequestBody);


//                var response = client.Execute(request);

//                // Parse response from ChatGPT API
//                var chatResponse = JsonConvert.DeserializeObject<ChatResponse>(response.Content);

//                // Display response in chat window
//                return Json(new
//                {
//                    text = chatResponse.Text
//                });
//            }
//        }
//    }



//}



using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreProject.Models;
using System.Diagnostics;
using Newtonsoft.Json;



namespace CoreProject.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SendMessage(chatRequest chatRquest)
        {
            var client = new RestClient("https://localhost:7205/");
            var request = new RestRequest("Chat/FromRequest", Method.Post);
            request.AddHeader("content-type", "application/json");
            //request.AddHeader("Authorization", "Bearer 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");
            //request.AddParameter("application/json", "{\"prompt\": \"" + userMessage + "\",\"temperature\":0.7,\"max_tokens\":60,\"top_p\":1,\"frequency_penalty\":0,\"presence_penalty\":0}", ParameterType.RequestBody);
            //request.AddParameter("application/json",  "{ \"botSettings\": {   \"name\": \"GLTExpress\",    \"botName\": \"random arabic name\",  \"position\": \"Call center representative\",    \"url\": \"gltmena.com\",   \"language\": \"arabic\",    \"feild\": \"logistics\",    \"options\": 1,    \"moreInfo\": \"\"  },  \"messages\": [    {      \"role\": \"user\",     \"content\": \" " +userMessage+"\"   } ]}", ParameterType.RequestBody);
            request.AddParameter("application/json", JsonConvert.SerializeObject(chatRquest), ParameterType.RequestBody);

            RestResponse response = client.Execute(request);
            var chatResponse = response.Content;
            Root test =  JsonConvert.DeserializeObject<Root>(response.Content);
            return Ok(test.choices[0].message.content);
        }
    }
}

