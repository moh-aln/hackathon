﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$(document).ready(function () {
    $('#chat-form').on('submit', function (e) {
        e.preventDefault();
        var message = $('#chat-input').val();
        $('#chat-input').val('');

        $.ajax({
            url: '@Url.Action("Index", "Chat")',
            type: 'POST',
            data: { message: message },
            success: function (response) {
                $('#chat-messages').append('<div class="message"><div class="message-text">' + message + '</div></div>');
                $('#chat-messages').append('<div class="message"><div class="message-text">' + response.text + '</div></div>');
            }
        });
    });


    success: function (chatResponse) {
        // Append the user's message to the chat window
        $('#chatWindow').append('<div class="userMessage">' + message + '</div>');

        // Append the chatbot's response to the chat window
        $('#chatWindow').append('<div class="botMessage">' + chatResponse + '</div>');

        // Clear the input field
        $('#inputField').val('');

        // Scroll to the bottom of the chat window
        $('#chatWindow').scrollTop($('#chatWindow')[0].scrollHeight);
    }