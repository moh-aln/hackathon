﻿$(function () {
    // Submit the form when the Send button is clicked
    $('#chat-send-btn').click(function (event) {
        event.preventDefault();
        sendMessage();
    });

    // Submit the form when Enter is pressed in the input field
    $('#chat-input').keypress(function (event) {
        if (event.which == 13) {
            event.preventDefault();
            sendMessage();
        }
    });

    function sendMessage() {
        // Get the user's message from the input field
        var message = $('#chat-input').val();

        // Append the user's message to the chat messages
        var userMessage = '<div class="message"><div class="message-text user-message">' + message + '</div></div>';
        $('#chat-messages').append(userMessage);

        // Send the message to the chatbot API
        $.ajax({
            url: '/Home/GetResponse',
            type: 'POST',
            dataType: 'text',
            data: { message: message },
            success: function (chatResponse) {
                // Append the chatbot's response to the chat messages
                var botMessage = '<div class="message"><div class="message-text bot-message">' + chatResponse + '</div></div>';
                $('#chat-messages').append(botMessage);

                // Clear the input field
                $('#chat-input').val('');

                // Scroll to the bottom of the chat messages
                $('#chat-messages').scrollTop($('#chat-messages')[0].scrollHeight);
            },
            error: function (xhr, status, error) {
                // Handle errors here
            }
        });
    }
});
